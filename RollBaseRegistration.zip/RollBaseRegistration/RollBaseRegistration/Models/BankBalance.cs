﻿using System.ComponentModel.DataAnnotations;

namespace RollBaseRegistration.Models
{
    public class BankBalance
    {
        [Key]
        public int Id { get; set; }

        
        public string? Username { get; set; }

        
        public int? Pin { get; set; }

        public int? Balance { get; set; }

    }
}
