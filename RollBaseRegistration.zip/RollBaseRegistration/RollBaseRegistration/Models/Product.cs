﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace RollBaseRegistration.Models
{
    public class Product
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string? Description { get; set; }
        public decimal price { get; set;}

        [Display(Name="Image")]
        public string? ImagePath { get; set; }
        public int subcategoriesid { get; set; }
        public  Subcategories Subcategories { get; set; }

        public string UserId { get; set; }

        public RoleBaseTable User { get; set; }
        

    }
}
