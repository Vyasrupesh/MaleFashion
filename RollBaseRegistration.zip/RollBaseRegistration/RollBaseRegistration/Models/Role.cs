﻿using System.ComponentModel.DataAnnotations;

namespace RollBaseRegistration.Models
{
    public class Role
    {
        
        public string? Id { get; set; }
        [Required]
        [Display(Name = "Role")]
        public string? RoleName { get; set; }
        public bool Selected { get; internal set; }
    }
}
