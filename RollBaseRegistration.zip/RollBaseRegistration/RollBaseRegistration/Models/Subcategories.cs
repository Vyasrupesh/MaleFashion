﻿using System.ComponentModel.DataAnnotations;

namespace RollBaseRegistration.Models
{
    public class Subcategories
    {
        [Key]
        public int Id { get; set; }
        
        public string? Name { get; set; }

        public int? categoryid { get; set; }

        public Category Category { get; set; }

        public List<Product> Products { get; set; }


    }
}
