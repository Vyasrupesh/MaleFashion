﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace RollBaseRegistration.Models
{
    public class Category
    {
        [Key]
        public int Id { get; set; }
        public string? Name { get; set; }

        public List<Subcategories> subcategories { get; set; }

    }
}
