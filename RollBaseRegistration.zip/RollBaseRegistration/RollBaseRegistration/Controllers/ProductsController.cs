﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using RollBaseRegistration.DataContext;
using RollBaseRegistration.Models;
using RollBaseRegistration.viewModal;

namespace RollBaseRegistration.Controllers
{
    public class ProductsController : Controller
    {
        private readonly UserManager<RoleBaseTable> _userManager;
        private readonly RoleManager<IdentityRole> _roleManager;
        private readonly ApplicationDbContext _context;
        private readonly IWebHostEnvironment _environment;

        public ProductsController(ApplicationDbContext context , IWebHostEnvironment environment , UserManager<RoleBaseTable> userManager, RoleManager<IdentityRole> roleManager)
        {

            _context = context;
            _environment = environment;
            _userManager = userManager;
            _roleManager = roleManager;

        }

        // GET: Products
        public async Task<IActionResult> Index(int? pageNumber)
        {
            var currentUser = await _userManager.GetUserAsync(User);
            if (User.IsInRole("admin"))
            {
                var applicationDbContext = _context.Products.Include(p => p.Subcategories).Include(u => u.User);
                var product = await applicationDbContext.ToListAsync();
                if (pageNumber < 1)
                {
                    pageNumber = 1;
                }
                int pageSize = 2;
                var modalList = PaginatedList<Product>.Create(product, pageNumber ?? 1, pageSize);
                return View(modalList);
            }
            else
            {
                var applicationDbContext = _context.Products.Where(u=> u.UserId == currentUser.Id).Include(p => p.Subcategories);
                var product = await applicationDbContext.ToListAsync();
                if (pageNumber < 1)
                {
                    pageNumber = 1;
                }
                int pageSize = 2;
                var modalList = PaginatedList<Product>.Create(product, pageNumber ?? 1, pageSize);
                return View(modalList);


            }
            
        }

        // GET: Products/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null || _context.Products == null)
            {
                return NotFound();
            }

            var product = await _context.Products
                .Include(p => p.Subcategories)
                .FirstOrDefaultAsync(m => m.Id == id);
            if (product == null)
            {
                return NotFound();
            }

            return View(product);
        }

        // GET: Products/Create
        public IActionResult Create()
        {

           ViewData["categoryid"] = new SelectList(_context.Categories, "Id", "Name");


            return View();
        }

        [HttpPost]
        public JsonResult GetSubcategories(int categoryId)
        {
            var subcategories = _context.Subcategories.Where(s => s.categoryid == categoryId).Select(s => new { s.Id, s.Name }).ToList();

            return Json(subcategories);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create( ProductViewModel model)
        {
            var currentUser = await _userManager.GetUserAsync(User);
            var uploadImage = ProductUploadedFile(model);
            if (ModelState.IsValid)
            {
                //var currentUser = await _userManager.GetUserAsync(User);
                //var uploadImage = ProductUploadedFile(model);
                var product = new Product
                {
                    Name = model.Name,
                    price=model.price,
                    Description=model.Description,
                    ImagePath= uploadImage,
                    subcategoriesid = model.subcategoriesid,
                    UserId= currentUser.Id

                };
                _context.Add(product);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            ViewData["subcategoriesid"] = new SelectList(_context.Subcategories, "Id", "Name", model.subcategoriesid);
            ViewData["categoryid"] = new SelectList(_context.Categories, "Id", "Name",model.categoryid);
            return View(model);
        }

        // GET: Products/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null || _context.Products == null)
            {
                return NotFound();
            }

            var product = await _context.Products.FindAsync(id);
            var ProductViewModel = new ProductViewModel()
            {
                Name = product.Name,
                price = product.price,
                Description = product.Description,
                subcategoriesid = product.subcategoriesid,
                ImagePath = product.ImagePath
            };
            if (product == null)
            {
                return NotFound();
            }
            ViewData["subcategoriesid"] = new SelectList(_context.Subcategories, "Id", "Name", product.subcategoriesid);
            return View(ProductViewModel);
        }

        // POST: Products/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(ProductViewModel model)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    var product = await _context.Products.FindAsync(model.Id);
                    string filePath = Path.Combine(_environment.WebRootPath, "Image/Product/", product.ImagePath);
                    if (product is null)
                    {
                        return NotFound();
                    }
                    product.Name = model.Name;
                    product.Description = model.Description;
                    product.price = model.price;
                    product.subcategoriesid = model.subcategoriesid;

                    if (model.ProductImage is null)
                    {
                        product.ImagePath = product.ImagePath;


                    }
                    else
                    {
                        if (product.ImagePath != null)
                        {
                            //string filePath = Path.Combine(_environment.WebRootPath, "Image/Product/", product.ImagePath);
                            System.IO.File.Delete(filePath);
                        }
                            product.ImagePath = ProductUploadedFile(model);
 
                    }
                    _context.Update(product);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!ProductExists(model.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            ViewData["subcategoriesid"] = new SelectList(_context.Subcategories, "Id", "Name", model.subcategoriesid);
            return View(model);
        }

       
        
        public async Task<IActionResult> Delete(ProductViewModel model)
        {
            var product = await _context.Products.FindAsync(model.Id);
            string filePath = Path.Combine(_environment.WebRootPath, "Image/Product/", product.ImagePath);
            if (_context.Products == null)
            {
                return Problem("no product are selected.");
            }
            
            if(System.IO.File.Exists(filePath))
            {
                System.IO.File.Delete(filePath);
            }
            if (product != null)
            {
                _context.Products.Remove(product);
            }
            
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool ProductExists(int id)
        {
          return (_context.Products?.Any(e => e.Id == id)).GetValueOrDefault();
        }


        //private string ProductUploadedFile(ProductViewModel model)
        //{
        //    string uniqueFileName = String.Empty;
        //    string path = Path.Combine(_environment.WebRootPath, "Images/Product/");
        //    if (!Directory.Exists(path))
        //    {
        //        Directory.CreateDirectory(path);
        //    }

        //    if (model.ProductImage != null)
        //    {
        //        string uploadsFolder = Path.Combine(_environment.WebRootPath, "Images/Product/");
        //        uniqueFileName = Guid.NewGuid().ToString() + "_" + model.ProductImage.FileName;
        //        string filePath = Path.Combine(uploadsFolder, uniqueFileName);
        //        using (var fileStream = new FileStream(filePath, FileMode.Create))
        //        {
        //            model.ProductImage.CopyTo(fileStream);
        //        }
        //    }

        //    return uniqueFileName;
        //}

        private string ProductUploadedFile(ProductViewModel model)
        {
            string uniqueFileName = String.Empty;
            if(model.ProductImage != null)
            {
                string uploadsFolder = Path.Combine(_environment.WebRootPath, "Image/Product/");
                uniqueFileName = Guid.NewGuid().ToString() + "_" + model.ProductImage.FileName;
                string filePath = Path.Combine(uploadsFolder, uniqueFileName);
                using (var fileStream = new FileStream(filePath, FileMode.Create))
                {
                    model.ProductImage.CopyTo(fileStream);
                }
            }
            return uniqueFileName;
        }



    }
}
