﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace RollBaseRegistration.Controllers
{
    public class demo : Controller
    {
        public string Name { get; private set; }

        public IActionResult Index()
        {
            return View();
        }

        //public IActionResult GetBaseges()
        //{
        //    // Retrieve baseges from the database or any other data source
        //    List<string> baseges = new List<string> { "Basege1", "Basege2", "Basege3" };
        //    return Json(baseges);
        //}

        public JsonResult AddData(string name)
        {
            //name = Name;
            return Json(new { success = true  });
            //if (ModelState.IsValid)
            //{
            //    //_context.ExampleModels.Add(model);
            //    //_context.SaveChanges();
            //    return Json(new { success = true });
            //}
            //return Json(new { success = false, errors = ModelState.Values.SelectMany(x => x.Errors).Select(x => x.ErrorMessage) });
        }
    }
}
