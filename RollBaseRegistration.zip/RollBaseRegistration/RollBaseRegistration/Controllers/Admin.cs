﻿using System.Data;
using System.Linq;
using System.Net;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using NuGet.Common;
using NuGet.Packaging.Signing;
using RollBaseRegistration.Models;

namespace RollBaseRegistration.Controllers
{
	public class Admin : Controller
	{
		private readonly UserManager<RoleBaseTable> _userManager;
		private readonly RoleManager<IdentityRole> _roleManager;


		public Admin(UserManager<RoleBaseTable> userManager, RoleManager<IdentityRole> roleManager)
		{
			_userManager = userManager;
			_roleManager = roleManager;


		}

		[HttpGet]
		public IActionResult Index(int? pageNumber)
		{

            var usersWithRoles = _userManager.Users.Select(user => new ManageUser
        {
            FirstName = user.FirstName,
			LastName=user.LastName,
			Email = user.Email,
            RoleName = _userManager.GetRolesAsync(user).Result.FirstOrDefault(),
            PhoneNumber=user.PhoneNumber,
			Address=user.Address

            }).ToList();


            //var users = _userManager.Users.ToList();

            if (pageNumber < 1)
			{
				pageNumber = 1;
			}

			int pageSize = 2;
			var modalList = PaginatedList<ManageUser>.Create(usersWithRoles, pageNumber ?? 1, pageSize);
            return View(modalList);
        }

		[HttpGet]
		public IActionResult create()
		{
            // Populate roles for dropdown
            //ViewBag.Roles = _roleManager.Roles.ToList();
            var roles = _roleManager.Roles.ToList();
            var model = new ManageUser
			{
                RoleSelectList = new SelectList(roles)
            };


            return View(model);
		}

		[HttpPost]
		public async Task<IActionResult> create(ManageUser model)
		{
			
			if (ModelState.IsValid)
			{
				var user = new RoleBaseTable {

					FirstName = model.FirstName,
					LastName = model.LastName,
					UserName = model.Email,
					Email = model.Email,
					PhoneNumber = model.PhoneNumber,
					Address = model.Address,
				};


				var result = await _userManager.CreateAsync(user, model.Password);

				if (result.Succeeded)
				{
					// Assign the selected role to the new user
					if (model.RoleName == "null")

                    {
						ViewBag.ErrorMessage = "Please select any one Role";
						return View();

					}
					else
					{
						await _userManager.AddToRoleAsync(user, model.RoleName);
					}
					// Redirect to login or other success action
					return RedirectToAction("index");
				}

				foreach (var error in result.Errors)
				{
					ModelState.AddModelError(string.Empty, error.Description);
				}
			}
			// Repopulate roles for dropdown on validation failure
			return View(model);
		}

		[HttpGet]
		public async Task<IActionResult> Edit(string id)
		{
           

            var User = await _userManager.FindByIdAsync(id);
            if (User == null)
			{
				
				return View("Error");
			}

            var roles = _roleManager.Roles.ToList();
            var userRoles = _userManager.GetRolesAsync(User).Result;

            var model = new ManageUser
           {
				Id = User.Id,
				FirstName = User.FirstName,
				LastName = User.LastName,
				Email = User.Email,
				PhoneNumber = User.PhoneNumber,
				Address = User.Address,
                RoleName = userRoles.FirstOrDefault(),
                RoleSelectList = new SelectList(roles)
            };
           // ViewBag.Roles = _roleManager.Roles.ToList();
            return View(model);
		}

		[HttpPost]
		public async Task<IActionResult> Edit(ManageUser model)
		{

			if (ModelState.IsValid)
			{
				var User = await _userManager.FindByIdAsync(model.Id);

				if (User != null)
				{
                    
                        var currentRole = _userManager.GetRolesAsync(User).Result.FirstOrDefault();
                        if (currentRole != model.RoleName)
                        {
                            // Remove the user from the current role
                            await _userManager.RemoveFromRoleAsync(User, currentRole);

                            // Add the user to the new role
                            await _userManager.AddToRoleAsync(User, model.RoleName);
                        }

                    User.FirstName = model.FirstName;
					User.LastName = model.LastName;
					User.UserName = model.Email;
					User.Email = model.Email;
					User.PhoneNumber = model.PhoneNumber;
					User.Address = model.Address;
					// Update other properties as needed

					if (model.Password != null)
					{
						var token = await _userManager.GeneratePasswordResetTokenAsync(User);
						var Updatepass = await _userManager.ResetPasswordAsync(User, token, model.Password);
						if (!Updatepass.Succeeded)
						{
							ViewBag.ErrorMessage = "Password was not updated";
							return View();
						}
					}

					var result = await _userManager.UpdateAsync(User);

					if (result.Succeeded)
					{
						
						// Redirect to user list or details page
						return RedirectToAction("Index"); // Adjust as needed
					}

					foreach (var error in result.Errors)
					{
						ModelState.AddModelError(string.Empty, error.Description);
					}
				}
				else
				{
					return NotFound();
				}

			}
            foreach (var modelState in ModelState.Values)
            {
                foreach (var error in modelState.Errors)
                {
                    // Log or inspect the error messages
                    Console.WriteLine(error.ErrorMessage);
                }
            }
          
			return View(model);
		}

        public async Task<IActionResult> Delete(ManageUser model)
        {
            var User = await _userManager.FindByIdAsync(model.Id); 
            if (User == null)
            {
                // User not found, handle accordingly
                ViewBag.ErrorMessage = $"User with Id = {model.Id} cannot be found";
                return View("Index");
            }
            var result = await _userManager.DeleteAsync(User);
            if (result.Succeeded)
            {
                //TempData["Update"] = "Role Deleted Successfully";
                // User deletion successful
                return RedirectToAction("Index"); // Redirect to the User list page

            }
            foreach (var error in result.Errors)
            {
                ModelState.AddModelError("", error.Description);
            }
            // If we reach here, something went wrong, return to the view
            return View("Index");
        }



    }
			
}
		
	



