﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using RollBaseRegistration.DataContext;
using RollBaseRegistration.Models;
using RollBaseRegistration.viewModal;

namespace RollBaseRegistration.Controllers
{
    public class SubcategoriesController : Controller
    {
        private readonly ApplicationDbContext _context;

        public SubcategoriesController(ApplicationDbContext context)
        {
            _context = context;
        }

        // GET: Subcategories
        public async Task<IActionResult> Index(int? pageNumber)
        {
            var applicationDbContext = _context.Subcategories.Include(s => s.Category);
            var Subcategory = await applicationDbContext.ToListAsync();
            if (pageNumber < 1)
            {
                pageNumber = 1;
            }
            int pageSize = 2;
            var modalList = PaginatedList<Subcategories>.Create(Subcategory, pageNumber ?? 1, pageSize);
            return View(modalList);
        }

      
        public IActionResult Create()
        {
            ViewData["categoryid"] = new SelectList(_context.Categories, "Id", "Name");
            return View();
        }

        
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Id,Name,categoryid")]SubcategoryViewModal modal)
        {
            if (ModelState.IsValid)
            {
                var subcategories = new Subcategories
                {
                    Name = modal.Name,
                    categoryid=modal.categoryid
                };
                _context.Add(subcategories);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            ViewData["categoryid"] = new SelectList(_context.Categories, "Id", "Name", modal.categoryid);
            return View(modal);
        }

      
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null || _context.Subcategories == null)
            {
                return NotFound();
            }

            var subcategories = await _context.Subcategories.FindAsync(id);
            if (subcategories == null)
            {
                return NotFound();
            }
            ViewData["categoryid"] = new SelectList(_context.Categories, "Id", "Name", subcategories.categoryid);
            return View(subcategories);
        }

        
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(SubcategoryViewModal modal)
        {

            if (ModelState.IsValid)
            {
                try
                {
                    var subcategories = await _context.Subcategories.FindAsync(modal.Id);
                    if (subcategories is null)
                    {
                        return NotFound();
                    }
                    subcategories.Name = modal.Name;
                    subcategories.categoryid = modal.categoryid;
                    _context.Update(subcategories);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!SubcategoriesExists(modal.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            ViewData["categoryid"] = new SelectList(_context.Categories, "Id", "Name", modal.categoryid);
            return View(modal);
        }

        // POST: Subcategories/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Delete(int id)
        {
            if (_context.Subcategories == null)
            {
                return Problem("Entity set 'ApplicationDbContext.Subcategories'  is null.");
            }
            var subcategories = await _context.Subcategories.FindAsync(id);
            if (subcategories != null)
            {
                _context.Subcategories.Remove(subcategories);
            }
            
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool SubcategoriesExists(int id)
        {
          return (_context.Subcategories?.Any(e => e.Id == id)).GetValueOrDefault();
        }
    }
}
