﻿using System.Linq;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RollBaseRegistration.DataContext;
using RollBaseRegistration.Models;
using RollBaseRegistration.viewModal;

namespace RollBaseRegistration.Controllers
{
    public class UserBankBalance : Controller
    {
        private readonly ApplicationDbContext _context;

        public UserBankBalance(ApplicationDbContext context )
        {

            _context = context;
        }
        // GET: UserBankBalance
        public ActionResult Index(BankBalanceViewModel model)
        {
            return View();
        }

        // GET: UserBankBalance/Details/5
        public ActionResult Details(int id)
        {
            return View();
        }
        public ActionResult Login()
        {
            return View();
        }

        
        [HttpPost]
        public async Task<ActionResult> Login(BankBalanceViewModel model)
        {
            try
            {
                var user = _context.BankBalances.FirstOrDefault(u=>u.Username == model.Username);
               
                
                    if (user.Pin == model.Pin)
                    {

                    return RedirectToAction(nameof(Index));

                    }
                
            }
            
            catch
            {
                return View();
            }
            ModelState.AddModelError("", "User not exist");
            return View( model);
        }





        // GET: UserBankBalance/Create
        public ActionResult CreateAsync()
        {
            return View();
        }

        // POST: UserBankBalance/Create
        [HttpPost]
        public async Task<ActionResult> Create(BankBalanceViewModel model)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    //var currentUser = await _userManager.GetUserAsync(User);
                    //var uploadImage = ProductUploadedFile(model);
                    var BankBalance = new BankBalance
                    {
                        Username = model.Username,
                        Pin = model.Pin,

                    };
                    _context.Add(BankBalance);
                    await _context.SaveChangesAsync();
                    return RedirectToAction(nameof(Login));
                }
            }
            catch
            {
                return View();
            }
            return View(model);
        }

        public async Task<IActionResult> Logout()
        {
            // Implement your logout logic here
            

            return RedirectToAction("Login");
        }







        
        public ActionResult DepogitAsync()
        {
            return View();
        }

        // POST: UserBankBalance/Edit/5
        [HttpPost]
        
        public async Task<ActionResult> Depogit(BankBalanceViewModel model)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    var user = _context.BankBalances.FirstOrDefault();
                    var totalbalance = user.Balance + model.amount;

                    user.Balance = (int)totalbalance;

                    _context.Update(user);
                    await _context.SaveChangesAsync();
                    return RedirectToAction(nameof(Index));
                }
                catch
                {
                    return View();
                }
            }
           
          return View(model);

        }


        public ActionResult DebiteAsync()
        {
            return View();
        }

        // POST: UserBankBalance/Edit/5
        [HttpPost]

        public async Task<ActionResult> Debite(BankBalanceViewModel model)
        {
            
          
            
                try
                {
                    var user = _context.BankBalances.FirstOrDefault();
                    int hundrad = 100 * model.hundred;
                    int fivehundrad = 500 * model.fivehundred;
                    int towthousand = 2000 * model.twothousand;
                    int total = hundrad + fivehundrad + towthousand;
                    if (total! > model.amount)
                    {
                        ModelState.AddModelError("amount", "total sum of notes can not grater then amount.");

                    }
                    if (model.amount! > user.Balance)
                    {
                        ModelState.AddModelError("amount", " amount is greter then currente balance");
                    }


                    var totalbalance = user.Balance - model.amount;

                    user.Balance = (int)totalbalance;

                    _context.Update(user);
                    await _context.SaveChangesAsync();
                    return RedirectToAction(nameof(Index));
                }
                catch
                {
                    return View();
                }
            

            return View(model);

        }

        // GET: UserBankBalance/Delete/5
        public ActionResult Delete(int id)
        {
            return View();
        }

        // POST: UserBankBalance/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Delete(int id, IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }
    }
}
