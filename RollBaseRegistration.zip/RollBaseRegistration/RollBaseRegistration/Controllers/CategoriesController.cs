﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Internal;
using RollBaseRegistration.DataContext;
using RollBaseRegistration.Models;
using RollBaseRegistration.viewModal;

namespace RollBaseRegistration.Controllers
{
    public class CategoriesController : Controller
    {
        private readonly ApplicationDbContext _context;

        public CategoriesController(ApplicationDbContext context)
        {
            _context = context;
        }

        // GET: Categories
        public async Task<IActionResult>Index(int? pageNumber)
        {

                var category = await _context.Categories.ToListAsync();
            if (pageNumber < 1)
            {
                pageNumber = 1;
            }
            int pageSize = 2;
                var modalList = PaginatedList<Category>.Create(category, pageNumber ?? 1, pageSize);
                return View(modalList);
        }

        // GET: Categories/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: Categories/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(CategoryViewModal modal)
        {
            if (ModelState.IsValid)
            {
                var category = new Category
                {
                    Name = modal.Name
                };
                _context.Add(category);
                await _context.SaveChangesAsync();
                TempData["Seccess"] = "Category add Successfully";
                return RedirectToAction(nameof(Index));
            }
            return View(modal);
        }

        // GET: Categories/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            var category = await _context.Categories.FindAsync(id);

            if (category == null || _context.Categories == null)
            {
                return NotFound();
            }
            var model = new CategoryViewModal
            {
                Name= category.Name
                
            };
            if (category == null)
            {
                return NotFound();
            }
            return View(model);
        }

        // POST: Categories/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(CategoryViewModal modal)
        {

            if (ModelState.IsValid)
            {
                try
                {
                    var category = await _context.Categories.FindAsync(modal.Id);

                    if (category is null)
                    {
                        return NotFound();
                    }
                    category.Name = modal.Name;
                    _context.Update(category);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!CategoryExists(modal.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                TempData["Edit-Seccess"] = "Category Edit Successfully";
                return RedirectToAction(nameof(Index));
            }
            return View(modal);
        }

        // POST: Categories/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Delete(int id)
        {
            if (_context.Categories == null)
            {
                return Problem("Entity set 'ApplicationDbContext.Categories'  is null.");
            }
            var category = await _context.Categories.FindAsync(id);
            if (category != null)
            {
                _context.Categories.Remove(category);
            }
            
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool CategoryExists(int id)
        {
          return (_context.Categories?.Any(e => e.Id == id)).GetValueOrDefault();
        }
    }
}
