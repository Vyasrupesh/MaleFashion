﻿using System.ComponentModel.DataAnnotations;

namespace RollBaseRegistration.viewModal
{
    public class BankBalanceViewModel
    {


        public string? Username { get; set; }

        public int? Pin { get; set; }


        
        
        [Compare("Pin", ErrorMessage = "The password and confirmation password do not match.")]
        public int ConfirmPin { get; set; }
        public int? Balance { get; set; }
       
        
        public int? amount { get; set; }

        public int hundred { get; set; }
        public int fivehundred { get; set; }    
        public int twothousand { get; set; }
    }
}
