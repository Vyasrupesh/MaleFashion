﻿using System.ComponentModel.DataAnnotations;

namespace RollBaseRegistration.viewModal
{
    public class ProductViewModel
    {

        public int Id { get; set; }

        [Required(ErrorMessage = " Product Name is required")]
        public string Name { get; set; }
        public string? Description { get; set; }
        [Required]
        [Range(0.01, double.MaxValue, ErrorMessage = "Price must be greater than 0")]
        public decimal price { get; set; }

        public string? ImagePath { get; set; }

        public IFormFile?  ProductImage { get; set; }
        public int subcategoriesid { get; set; }

        public int categoryid { get; set; }



    }
}
