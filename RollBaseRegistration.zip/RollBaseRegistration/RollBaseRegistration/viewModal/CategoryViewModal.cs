﻿using System.ComponentModel.DataAnnotations;

namespace RollBaseRegistration.viewModal
{
    public class CategoryViewModal
    {
        public int Id { get; set; }

        [Required(ErrorMessage = "Name is required")]
        public string? Name { get; set; }
    }
}
