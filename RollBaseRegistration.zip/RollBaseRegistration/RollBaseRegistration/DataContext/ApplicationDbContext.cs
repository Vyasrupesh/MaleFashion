﻿using System.Reflection.Emit;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using RollBaseRegistration.Models;

namespace RollBaseRegistration.DataContext
{
    public class ApplicationDbContext : IdentityDbContext<RoleBaseTable>
    {

        public ApplicationDbContext(DbContextOptions options):base(options)
        {

        }



          public DbSet<Category> Categories { get; set; }
           public DbSet<Subcategories> Subcategories { get; set; }

        public DbSet<Product> Products { get; set; }
        public DbSet<BankBalance> BankBalances { get; set; }

        //protected override void OnModelCreating(ModelBuilder builder)
        //{


        //}
    }
}
